#!/bin/bash

unsealkey1=`kubectl get secret ainative-openbao-key1 --template={{.data.Unseal}} | base64 --decode`

unsealkey2=`kubectl get secret ainative-openbao-key2 --template={{.data.Unseal}} | base64 --decode`

unsealkey3=`kubectl get secret ainative-openbao-key3 --template={{.data.Unseal}} | base64 --decode`

unsealkey4=`kubectl get secret ainative-openbao-key4 --template={{.data.Unseal}} | base64 --decode`

unsealkey5=`kubectl get secret ainative-openbao-key5 --template={{.data.Unseal}} | base64 --decode`


status="$(kubectl exec ai-native-openbao-0 -- bao status | awk 'NR==5 {print; exit}'| awk '{print $2}')"

if [ $status="true" ]
then
  entries=($(shuf -i 1-5 -n 3))

  echo -e "\n======================================"
  for entry in "${entries[@]}";
  do
     key="unsealkey${entry}"
     echo -e "Unsealing the openbao..."
     echo -e "\n"
     kubectl exec ai-native-openbao-0 -- bao operator unseal ${!key}
     sleep 1
     echo -e "\n======================================"
done
fi

echo -e "\n openbao has been Unsealed successfully!!!"

echo -e "\nChecking the openbao status"
kubectl exec ai-native-openbao-0 -- bao status
##EOF##
