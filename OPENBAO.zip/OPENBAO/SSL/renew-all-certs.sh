#!/bin/bash

###################################  JORITZ VAULT CERTIFICATES  ##########################################

### Fetch Inputs ###

read -p "Please provide us the Virtual IP1 for Vault: " CN
read -p "Please provide us the Public IP: " IP2
read -p "Please provide us the DNS for Virtual IP: " DNS2


##########Creating CA Certificates ###############

#openssl req -x509 -sha256 -days 1825 -newkey rsa:2048 -keyout /app_data/DEPLOYMENTS/OPENBAO/SSL/caRoot.key -out /app_data/DEPLOYMENTS/OPENBAO/SSL/caRoot.crt

#echo -e "\n caRoot.crt and caRoot.key has been successfully created at /app_data/DEPLOYMENTS/OPENBAO/SSL/!!!"

###Create the Vault Private Key###

openssl genrsa -out /app_data/DEPLOYMENTS/OPENBAO/SSL/vault.key 2048

### Generate Certificate Signing Request (CSR) Using Vault Private Key###

openssl req -new -key /app_data/DEPLOYMENTS/OPENBAO/SSL/vault.key -out /app_data/DEPLOYMENTS/OPENBAO/SSL/vault.csr -config /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao.cfr

###Create a external file###

cat > /app_data/DEPLOYMENTS/OPENBAO/SSL/cert.conf <<EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:TRUE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
subjectAltName = @alt_names

[alt_names]
IP.1 = ${CN}
IP.2 = ${IP2}
DNS.1 = ai-native-openbao-svc
DNS.2 = ${DNS2}
EOF

### Generate SSL certificate With self signed CA ###

openssl x509 -req -in /app_data/DEPLOYMENTS/OPENBAO/SSL/vault.csr -out vault.crt -key /app_data/DEPLOYMENTS/OPENBAO/SSL/vault.key -days 365 -sha256 -extfile /app_data/DEPLOYMENTS/OPENBAO/SSL/cert.conf

echo -e "\n vault.crt and vault.key has been successfully created at /app_data/DEPLOYMENTS/OPENBAO/SSL/!!!"

kubectl create secret generic ainative-openbao-secret --from-file=certificate.crt=/app_data/DEPLOYMENTS/OPENBAO/SSL/vault.crt --from-file=private.key=/app_data/DEPLOYMENTS/OPENBAO/SSL/vault.key


openssl req -x509 -batch -nodes -newkey rsa:2048 -keyout /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao-auth-key.pem -out /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao-auth-crt.pem -config /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao.cfr -days 365

openssl pkcs12 -export -out /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao-auth.p12 -inkey /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao-auth-key.pem -in /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao-auth-crt.pem  -password pass:changeit

keytool -importkeystore -deststorepass changeit -destkeystore /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao-auth.jks  -srckeystore /app_data/DEPLOYMENTS/OPENBAO/SSL/openbao-auth.p12 -srcstoretype PKCS12 -srcstorepass changeit

kubectl create secret generic openbao-auth --from-file=openbao-auth.jks=/app_data/DEPLOYMENTS/OPENBAO/SSL/openbao-auth.jks  --from-literal=keystore-password=changeit