#!/bin/bash

# An error exit function

error_exit()
{
  echo "$1" 1>&2
  exit 1
}

if kubectl exec ai-native-openbao-0 -- bao operator init > openbao_keys.txt; then
  echo -e "\nopenbao has been successfully initialized!!!"
else
  error_exit "ERROR: openbao Initialization failed"
fi

roottoken="$(awk 'NR==7 {print; exit}' openbao_keys.txt | awk '{print $4}' | awk '{print substr($0,0,28)}')"

unsealkey1="$(head -n 5 openbao_keys.txt  | awk '{print $4}' | awk 'NR==1 {print; exit}' | awk '{print substr($0,0,44)}')"
unsealkey2="$(head -n 5 openbao_keys.txt  | awk '{print $4}' | awk 'NR==2 {print; exit}' | awk '{print substr($0,0,44)}')"
unsealkey3="$(head -n 5 openbao_keys.txt  | awk '{print $4}' | awk 'NR==3 {print; exit}' | awk '{print substr($0,0,44)}')"
unsealkey4="$(head -n 5 openbao_keys.txt  | awk '{print $4}' | awk 'NR==4 {print; exit}' | awk '{print substr($0,0,44)}')"
unsealkey5="$(head -n 5 openbao_keys.txt  | awk '{print $4}' | awk 'NR==5 {print; exit}' | awk '{print substr($0,0,44)}')"

status="$(kubectl exec ai-native-openbao-0 -- openbao status | awk 'NR==5 {print; exit}'| awk '{print $2}')"

###To Unseal the openbao###

if [ $status="true" ]
then
  entries=($(shuf -i 1-5 -n 3))

  echo -e "\n======================================"
  for entry in "${entries[@]}";
  do
     key="unsealkey${entry}"
     echo -e "Unsealing the openbao..."
     echo -e "\n"
     kubectl exec ai-native-openbao-0 -- bao operator unseal ${!key}
     sleep 1
     echo -e "\n======================================"
done
else
error_exit "ERROR: openbao Unseal process failed..."
fi

echo -e "\nChecking the openbao status"
kubectl exec ai-native-openbao-0 -- bao status

echo -e "\n======================================"
echo -e "\nCreating the Kubernetes secret to store the keys and token"
kubectl create secret generic ainative-openbao-key1 --from-literal=Unseal=$unsealkey1
kubectl create secret generic ainative-openbao-key2 --from-literal=Unseal=$unsealkey2
kubectl create secret generic ainative-openbao-key3 --from-literal=Unseal=$unsealkey3
kubectl create secret generic ainative-openbao-key4 --from-literal=Unseal=$unsealkey4
kubectl create secret generic ainative-openbao-key5 --from-literal=Unseal=$unsealkey5
kubectl create secret generic ainative-openbao-root-token --from-literal=roottoken=$roottoken

echo -e "\n Deleting the openbao_keys.txt"
rm -r openbao_keys.txt
##EOF##



 
 