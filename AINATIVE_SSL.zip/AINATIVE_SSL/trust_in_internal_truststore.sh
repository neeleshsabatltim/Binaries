#!/bin/bash


logFile=trust-in-internal-truststore.log

echo "INFO ${date} Fetching the truststore password, please wait..."
echo "INFO ${date} Fetching the truststore password, please wait..." >> $logFile

## Fetching keystore password ##
keystorepass=$(kubectl get secret ainative-internal-truststore -o yaml | grep password | cut -f 2 -d ":" | sed 's/ //g' | base64 -d ) 2> lastError
if [ $? -ne 0 ]; then
        echo "ERROR ${date} Unable to get truststore password, exiting!! Check log file - $logFile for error"
        echo "ERROR ${date} Unable to get truststore password, exiting!!" >> $logFile
        cat lastError >> $logFile
        exit 1
else
        echo "INFO ${date} Truststore password fetched successfully"
        echo "INFO ${date} Truststore password fetched successfully" >> $logFile
fi


## Getting path to cetificate to be trusted ##

echo "#############################################################"
read -p "enter the alias of cert to be trusted : " cert_alias
read -p "enter the absolute path to cert to be trusted : " cert_path

echo "INFO ${date} Validating the certificate path, please wait...."
sleep 2
ls $cert_path 2> lastError
if [ $? -ne 0 ]; then
        echo "ERROR ${date} Unable to find certificate at $cert_path, ensure it is an absolute path, exiting!! Check log file - $logFile for error"
        echo "ERROR ${date} Unable to find certificate at $cert_path, ensure it is an absolute path, exiting!!" >> $logFile
        cat lastError >> $logFile
        exit 1
else
        echo "INFO ${date} Truststore password fetched successfully"
        echo "INFO ${date} Truststore password fetched successfully" >> $logFile
fi

echo "#############################################################"
read -p "Are you sure updated trustore is in pwd? (yes/no) : " continue
if [ "$continue" != "yes"  ];
then
        echo "Exiting script ..."
        exit 1
fi

echo "INFO ${date} Taking backup of truststore in pwd - joritz-internal-truststore.jks.bkp ..."
echo "INFO ${date} Taking backup of the truststore in pwd - joritz-internal-truststore.jks.bkp ..."
cp ainative-internal-truststore.jks ainative-internal-truststore.jks.bkp 2> lastError
if [ $? -ne 0 ]; then
        echo "ERROR ${date} Unable to take backup of truststore, exiting!! Check log file - $logFile for error"
        echo "ERROR ${date} Unable to take backup of truststore, exiting!!" >> $logFile
        cat lastError >> $logFile
        exit 1
else
        echo "INFO ${date} Truststore backed up successfully"
        echo "INFO ${date} Truststore   backed up successfully" >> $logFile
fi


echo "INFO ${date} Taking backup of truststore secret  in pwd - joritz-internal-truststore-secret-$(date +%m-%d).yaml.bkp ..."
echo "INFO ${date} Taking backup of truststore secret  in pwd - joritz-internal-truststore-secret-$(date +%m-%d).yaml.bkp ..."
kubectl get secret ainative-internal-truststore -o yaml > ainative-internal-truststore-secret-$(date +%m-%d).yaml.bkp 2> lastError
if [ $? -ne 0 ]; then
        echo "ERROR ${date} Unable to take backup of truststore secret, exiting!! Check log file - $logFile for error"
        echo "ERROR ${date} Unable to take backup of truststore secret, exiting!!" >> $logFile
        cat lastError >> $logFile
        exit 1
else
        echo "INFO ${date} Truststore secret backed up successfully"
        echo "INFO ${date} Truststore secret backed up successfully" >> $logFile
fi


echo "WARN ${date} Updating the truststore in pwd ..."

echo "WARN ${date} Updating the truststore in pwd ..." >> ${logFile}


## Trusting the certificate ##

keytool -import -v -trustcacerts -alias $cert_alias -file $cert_path -keystore ainative-internal-truststore.jks -keypass $keystorepass -storepass $keystorepass


echo "#############################################################"
read -p "Are you sure you want to update secret - ainative-internal-truststore (yes/no) : " continue
if [ "$continue" != "yes"  ];
then
        echo "Exiting script ..."
        exit 1
fi

echo "WARN ${date} Updating the truststore in pwd ..."

echo "WARN ${date} Updating the truststore in pwd ..." >> ${logFile}

## Patching the kubernetes secret ##

kubectl delete secret ainative-internal-truststore
kubectl create secret generic ainative-internal-truststore --from-file=ainative-internal-truststore.jks=ainative-internal-truststore.jks --from-literal=password=$keystorepass

echo "WARN ${date} Truststore updated ..."

echo "WARN ${date} Truststore updated ..." >> ${logFile}
