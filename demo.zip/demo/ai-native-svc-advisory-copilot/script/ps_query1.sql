CREATE TABLE IF NOT EXISTS system.vault_account_type
(
    account_type_id serial,
    name text ,
    description text , 
    created_by varchar(30) ,
    modified_by varchar(30) ,
    created_on varchar(30) ,
    modified_on varchar(30) ,
    PRIMARY KEY (account_type_id)
);



CREATE TABLE IF NOT EXISTS system.vault_account_action
(
    account_action_id serial,
    name text ,
    description text , 
    PRIMARY KEY (account_action_id)
);

CREATE TABLE IF NOT EXISTS system.vault_account_type_conn_map
(
    account_type_conn_map_id serial,
    account_type_id bigint,
    connector_id bigint,
    PRIMARY KEY (account_type_conn_map_id),
    FOREIGN KEY (account_type_id) REFERENCES system.vault_account_type (account_type_id),
    FOREIGN KEY (connector_id) REFERENCES system.core_connector (connector_id)
);

CREATE TABLE IF NOT EXISTS system.vault_account_type_method_map
(
    account_type_method_map_id serial,
    account_type_conn_map_id bigint,
    c_meta_method_id bigint,
    account_action_id bigint,
    PRIMARY KEY (account_type_method_map_id),
    FOREIGN KEY (account_type_conn_map_id) REFERENCES system.vault_account_type_conn_map (account_type_conn_map_id),
    FOREIGN KEY (c_meta_method_id) REFERENCES system.core_connector_metadata_method (c_meta_method_id),
    FOREIGN KEY (account_action_id) REFERENCES system.vault_account_action (account_action_id)
);


CREATE TABLE IF NOT EXISTS system.vault_account_type_tool_map
(
    account_type_tool_map_id serial,
    account_type_conn_map_id bigint,
    tool_id bigint,
    reference_id bigint,
    name text,
    description text,
    PRIMARY KEY (account_type_tool_map_id),
    FOREIGN KEY (account_type_conn_map_id) REFERENCES system.vault_account_type_conn_map (account_type_conn_map_id),
    FOREIGN KEY (tool_id) REFERENCES system.core_tool (tool_id)
);

